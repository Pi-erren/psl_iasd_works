rm project2022.zip
zip project2022.zip *
